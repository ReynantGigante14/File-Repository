from random import shuffle

class Quiz:

    __questions = {
        "question1" : ["aa", "bb", "cc", "dd", "b"],
        "question2" : ["cc", "dd", "ee", "ff", "b"],
        "question3" : ["a", "b", "c", "d", "b"],
        "question4" : ["a", "b", "c", "d", "b"],
        "question5" : ["a", "b", "c", "d", "b"],
    }


    def __init__(self) -> None:
        self.__score = 0
        self.__correctTotal = 0
        self.__incorrectTotal = 0

    def loadQuestions(self, noOfQuestions : int) -> dict[str, list] :
        # questions
        newDictionary = {}

        # question keys to be shuffled
        keys = list( self.__questions.keys() );

        #question counter
        num = 0

        # shuffling dictionary keys
        shuffle(keys);

        # looping through the first n keys
        for key in keys:
            newDictionary[key] = self.__questions[key]
            num += 1
            
            # exit loop if desired number of questions is reached
            if num == noOfQuestions: break

        return newDictionary

    def checkAnswer(self, question : dict, answer : str) -> bool:
        # get last item in question options and compare to answer
        if list(question.values())[0][4] == answer : 
            self.__score += 50
            self.__correctTotal += 1
            return True
        
        if list(question.values())[0][4] != answer :
            self.__incorrectTotal += 1
            return False

    def getScore(self) -> int:
        return self.__score

    def getCorrectTotal(self) -> int:
        return self.__correctTotal

    def getIncorrectTotal(self) -> int:
        return self.__incorrectTotal

    def getQuestionCount(self) -> int:
        return len(self.__questions)


    


        
