
while True:
    isdeciphering = input("Please select [0]Cipher/[1]Decipher: ")
    if isdeciphering != '0' and isdeciphering != '1': print("Invalid option. ", end='')
    else: break

while True:
    shifts = input("Enter the number of shift (1-25): ")
    if not shifts.isnumeric(): 
        print("Invalid shift. ", end='')
    else: 
        if int(shifts) < 1 or int(shifts) > 25: print("Invalid shift. ", end='')
        else: break

message = input("Enter the message: ").upper()
newmessage = ""
shifts = int(shifts)

for c in message:
    if not c.isalpha(): 
        newmessage += c
        continue
    index = ord(c) - shifts if isdeciphering == '1' else ord(c) + shifts
    if index > 90 : index = 65 + (index - 91)
    elif index < 65 : index = 91 - (65 - index)
    newmessage += chr(index)

print(newmessage)
