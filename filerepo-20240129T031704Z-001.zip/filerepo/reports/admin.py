from django.contrib import admin
from .models import Log
# Register your models here.

admin.site.register(Log)
